package com.example.demo.service;

import com.example.demo.modal.OrderItem;

public interface OrderItemService {
	
	public OrderItem createOrderItem(OrderItem orderItem);

}
