package com.chefhub.paymentgate.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.stereotype.Service;

import com.chefhub.paymentgate.dto.request.PaymentRequest;
import com.chefhub.paymentgate.model.Payment;
import com.chefhub.paymentgate.repository.PaymentRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PaymentService {
    private final PaymentRepository paymentRepo;

    public String pay(PaymentRequest request){
        var transactions = Payment.builder()
        .name(request.getName())
        .cardnumber(request.getCardnumber())
        .date(request.getDate())
        .code(request.getCode())
        .amount(request.getAmount())
        .build();
        paymentRepo.save(transactions);

        return "Payment Sucessfull";
    }
    
    public List<Payment> getAllPayments(){
        return paymentRepo.findAll();
    }
   
}
