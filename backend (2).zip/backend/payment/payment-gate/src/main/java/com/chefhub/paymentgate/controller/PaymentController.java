package com.chefhub.paymentgate.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.chefhub.paymentgate.dto.request.PaymentRequest;
import com.chefhub.paymentgate.model.Payment;
import com.chefhub.paymentgate.service.PaymentService;

import lombok.RequiredArgsConstructor;

@RequestMapping("/payment")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class PaymentController {
    private final PaymentService payservice;

    @PostMapping("/pay")
    public String payTransaction(@RequestBody PaymentRequest request){
        return payservice.pay(request);
    }

    @GetMapping("/getAllPayments")
    public List<Payment> getAllPayments(){
        return payservice.getAllPayments();
    }
}
