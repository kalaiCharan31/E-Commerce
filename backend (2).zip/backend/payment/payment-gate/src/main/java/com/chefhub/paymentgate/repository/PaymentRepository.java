package com.chefhub.paymentgate.repository;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.chefhub.paymentgate.model.Payment;

public interface PaymentRepository extends JpaRepository<Payment, String>{
    @Query("SELECT COUNT(p) FROM Payment p")
    Long totalTransaction();

    @Query("SELECT SUM(CAST(p.amount AS double)) FROM Payment p")
    Double totalAmount();

     @Query("SELECT SUM(CAST(p.amount AS double)) FROM Payment p WHERE p.date = :todayDate")
    Double calculateTotalAmountForToday(@Param("todayDate") String todayDate);
}
