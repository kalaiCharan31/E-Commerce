package com.bytebrawlers.feedback.constant;

public class Api {
    public static final String FEEDBACK = "/feedback";
}
