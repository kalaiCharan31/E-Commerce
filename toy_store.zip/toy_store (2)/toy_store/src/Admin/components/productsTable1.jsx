import React from 'react'

const productsTable1 = () => {
  return (
    <div>productsTable1</div>
  )
}

export default productsTable1