export const agetwelve=[
    {
        "image": "https://hmadmin.hamleys.in/product/493175425/300/LilE%20product%20DP.jpg",
        "brand": "Megawheels 36 V M3 Foldable Scooter",
        "title": "",
        "color": "",
        "selling_price": "₹1,455",
        "price": "₹1,599",
        "disscount": "9% off",
        "size": ""
    },
    {
        "image": "https://cdn.pixelspray.io/v2/black-bread-289bfa/HrdP6X/original/hamleys-product/491635759/300/491635759-1.webp",
        "brand": "X-shotX-Shot Chaos Meteorda",
        "title": "",
        "color": "",
        "selling_price": "₹1,117",
        "price": "₹1,999",
        "disscount": "44% off",
        "size": ""
    },
    {
        "image": "https://cdn.pixelspray.io/v2/black-bread-289bfa/HrdP6X/original/hamleys-product/493176630/300/493176630-1.jpeg",
        "brand": "LEGO® Hogwarts Express™",
        "title": "",
        "color": "",
        "selling_price": "₹499",
        "price": "₹998",
        "disscount": "50% off",
        "size": ""
    },
    {
        "image": "https://cdn.pixelspray.io/v2/black-bread-289bfa/HrdP6X/original/hamleys-product/491898739/300/491898739_2290.jpeg",
        "brand": "hoverboard All Terrain SelfBalancing Scooter",
        "title": "",
        "color": "",
        "selling_price": "₹299",
        "price": "₹1,299",
        "disscount": "76% off",
        "size": ""
    },
    {
        "image": "https://cdn.pixelbin.io/v2/black-bread-289bfa/HrdP6X/original/hamleys-product/492410364/300/492410364-1_1289.webp",
        "brand": "Hamley Retro Biplane Metal Airplane Model",
        "title": "",
        "color": "",
        "selling_price": "₹249",
        "price": "₹1,299",
        "disscount": "80% off",
        "size": ""
    },
    {
        "image": "https://cdn.pixelspray.io/v2/black-bread-289bfa/HrdP6X/original/hamleys-product/491602656/300/491602656.webp",
        "brand": "Remote Control Stunt Lateral and Oblique",
        "title": "",
        "color": "",
        "selling_price": "₹199",
        "price": "₹999",
        "disscount": "80% off",
        "size": ""
    },
]