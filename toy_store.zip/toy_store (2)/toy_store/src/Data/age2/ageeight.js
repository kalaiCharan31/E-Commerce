export const ageeight=[
    {
        "image": "https://toyzone.in/cdn/shop/products/723934_1024x1024@2x.jpg?v=1668491719",
        "brand": "Varuna Missile Launcher Truck",
        "title": "",
        "color": "Blue",
        "selling_price": "₹466",
        "price": "₹999",
        "disscount": "53% off",
        "size": ""
    },
    {
        "image": "https://cdn.pixelspray.io/v2/black-bread-289bfa/HrdP6X/original/hamleys-product/492908763/300/492908763-1.jpeg",
        "brand": "Cute Stuffed Supersoft Plush Sitting Tom Soft Toy",
        "title": "",
        "color": "Red",
        "selling_price": "₹449",
        "price": "₹1,099",
        "disscount": "59% off",
        "size": ""
    },
    {
        "image": "https://cdn.pixelspray.io/v2/black-bread-289bfa/HrdP6X/original/hamleys-product/491185766/300/491185766.webp",
        "brand": "Playnxt Pro Cricket Bat No. 4 Outdoor Sports ",
        "title": "",
        "color": "Beige",
        "selling_price": "₹298",
        "price": "₹1,599",
        "disscount": "81% off",
        "size": ""
    },
    {
        "image": "https://hmadmin.hamleys.in/product/493175341/300/493175341-1.jpg",
        "brand": "Berserk Balderov B7 Beyblade Burst DB QuadDrive",
        "title": "",
        "color": "Beige",
        "selling_price": "₹298",
        "price": "₹1,599",
        "disscount": "81% off",
        "size": ""
    },
    {
        "image": "https://cdn.pixelspray.io/v2/black-bread-289bfa/HrdP6X/original/hamleys-product/493176372/300/493176372-1.jpeg",
        "brand": "LEGO® Smashing Chimpanzee Stunt Loop",
        "title": "",
        "color": "Light Green",
        "selling_price": "₹284",
        "price": "₹1,599",
        "disscount": "82% off",
        "size": ""
    },
    {
        "image": "https://cdn.pixelspray.io/v2/black-bread-289bfa/HrdP6X/original/hamleys-product/492408132/300/492408132-1.jpeg",
        "brand": "Rallyez Pull Back Monster Friction Cars",
        "title": "",
        "color": "Dark Blue",
        "selling_price": "₹298",
        "price": "₹1,599",
        "disscount": "81% off",
        "size": ""
    },
]