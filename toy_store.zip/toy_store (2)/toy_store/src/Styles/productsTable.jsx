import React from 'react'

const productsTable = () => {
  return (
    <div>productsTable</div>
  )
}

export default productsTable