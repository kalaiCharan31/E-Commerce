export const Maincarouseldata=[
    {
        Image:"https://img.freepik.com/premium-photo/wooden-table-top-with-kids-toy-shopping-mall-blurry-background-ideal-commercial-use_937679-32002.jpg?w=1060",
        
    },
    {
        Image:"https://i.pinimg.com/564x/a3/2b/a6/a32ba600cd5ad799c07bb08e8f053a45.jpg",
        
    },
    {
        Image:"https://i.pinimg.com/564x/a7/a4/2d/a7a42d035c84d9a8951bc50c8d267e30.jpg",
        
    },
    {
        Image:"https://cdn.pixabay.com/photo/2018/09/06/23/14/toys-3659553_1280.jpg",
        
    },
]